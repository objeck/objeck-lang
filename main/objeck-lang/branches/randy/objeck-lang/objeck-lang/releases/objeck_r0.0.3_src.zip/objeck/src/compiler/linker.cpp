/***************************************************************************
 * Links pre-compiled code into existing program
 *
 * Copyright (c) 2008-2009, Randy Hollines
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 *
 * - Redistributions of source code must retain the above copyright 
 * notice, this list of conditions and the following disclaimer.
 * - Redistributions in binary form must reproduce the above copyright 
 * notice, this list of conditions and the following disclaimer in 
 * the documentation and/or other materials provided with the distribution.
 * - Neither the name of the LibraryVM Team nor the names of its 
 * contributors may be used to endorse or promote products derived 
 * from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED 
 * TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 *  PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF 
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ***************************************************************************/

#include "linker.h"
#include "../shared/instrs.h"

using namespace instructions;

void Linker::ResloveExternalCalls() {
  // all libraries
  map<const string, Library*>::iterator lib_iter;
  for(lib_iter = libraries.begin(); lib_iter != libraries.end(); lib_iter++) {
    // all classes
    vector<LibraryClass*> classes = lib_iter->second->GetClasses();
    for(unsigned int i = 0; i < classes.size(); i++) {
      // all methods
      map<const string, LibraryMethod*> methods = classes[i]->GetMethods();
      map<const string, LibraryMethod*>::iterator mthd_iter;
      for(mthd_iter = methods.begin(); mthd_iter != methods.end(); mthd_iter++) {
	vector<LibraryInstr*> instrs =  mthd_iter->second->GetInstructions();
	for(unsigned int j = 0; j < instrs.size(); j++) {
	  LibraryInstr* instr = instrs[j];
	  if(instr->GetType() == instructions::EXT_MTHD_CALL) {
	    LibraryClass* lib_klass = SearchClassLibraries(instr->GetOperand5());
	    if(lib_klass) {
	      LibraryMethod* lib_method = lib_klass->GetMethod(instr->GetOperand6());
	      if(lib_method) {
		instr->SetType(instructions::MTHD_CALL);
		instr->SetOperand(lib_klass->GetId());
		instr->SetOperand2(lib_method->GetId());
	      }
	      else {
		// TODO: better error handling
		cerr << "Error: Unable to resolve external library method: '" << instr->GetOperand6() << "'; check library path" << endl;
		exit(1);
	      }
	    }
	    else {
	      // TODO: better error handling
	      cerr << "Error: Unable to resolve external library class: '" << instr->GetOperand5() << "'; check library path" << endl;
	      exit(1);
	    }
	  }
	}
      }
    }
  }
}

/****************************
 * Returns all children related
 * to this class.
 ****************************/
vector<LibraryClass*> LibraryClass::GetLibraryChildren() {
  if(!lib_children.size()) {
    map<const string, const string> hierarchies = library->GetHierarchies();
    map<const string, const string>::iterator iter;
    for(iter = hierarchies.begin(); iter != hierarchies.end(); iter++) {
      if(iter->second == name) {
	lib_children.push_back(library->GetClass(iter->first));
      }
    }
  }
  
  return lib_children;
}

/****************************
 * Loads library file
 ****************************/
void Library::Load() {
#ifdef _DEBUG
  const string &msg = "=== Loading file: '" + lib_path + "' ===";
  Linker::Show(msg, 0, 0);
#endif
  LoadFile(lib_path);
}

/****************************
 * Reads a file
 ****************************/
void Library::LoadFile(const string &file_name) {
  // read file into memory
  ReadFile(file_name);
  // read strings
  const int num_char_strings = ReadInt();
  for(int i = 0; i < num_char_strings; i++) {
    const string &str_value = ReadString();
#ifdef _DEBUG
    cout << "string id=" << i << "; value='" << str_value << "'" << endl;
#endif
    StringInstruction* str_instr = new StringInstruction;
    str_instr->str_value = str_value;
    char_strings.push_back(str_instr);
  }
  // load enums and classes
  LoadEnums();
  LoadClasses();
}

/****************************
 * Reads enums
 ****************************/
void Library::LoadEnums() {
  const int number = ReadInt();
  for(int i = 0; i < number; i++) {
    // read enum
    const string &enum_name = ReadString();
    const INT_VALUE enum_offset = ReadInt();
    LibraryEnum* eenum = new LibraryEnum(enum_name, enum_offset);
    // read enum items
    const INT_VALUE num_items = ReadInt();
    for(int i = 0; i < num_items; i++) {
      const string &item_name = ReadString();
      const INT_VALUE item_id = ReadInt();
      eenum->AddItem(new LibraryEnumItem(item_name, item_id, eenum));
    }
    // add enum
    AddEnum(eenum);
  }
}

/****************************
 * Reads classes
 ****************************/
void Library::LoadClasses() {
  const int number = ReadInt();
  
  for(int i = 0; i < number; i++) {
    // id
    ReadInt();
    const string &name = ReadString();
    // pid
    ReadInt();
    const string &parent_name = ReadString();
    
    bool is_virtual = (bool)ReadInt();
    int cls_space = ReadInt();
    int inst_space = ReadInt();

    // read type parameters 
    backend::IntermediateDeclarations* entries = new backend::IntermediateDeclarations;
    int num_params = ReadInt();
    for(int i = 0; i < num_params; i++) {
      instructions::ParamType type = (instructions::ParamType)ReadInt();
      switch(type) {
      case instructions::OBJ_PARM:
      case instructions::OBJ_ARY_PARM:
        entries->AddParameter(new backend::IntermediateDeclaration(type, ReadInt()));
        break;

      default:
        entries->AddParameter(new backend::IntermediateDeclaration(type));
        break;
      }
    }
    hierarchies.insert(pair<const string, const string>(name, parent_name));
    
#ifdef _DEBUG
    const string& msg = "[class: name=" + name + "; parent=" + parent_name + "; virtual=" + 
      Linker::ToString(is_virtual) + "; class_mem_size=" + Linker::ToString(cls_space) + 
      "; instance_mem_size=" + Linker::ToString(inst_space) + "]";
    Linker::Show(msg, 0, 0);
#endif
    
    LibraryClass* cls = new LibraryClass(name, parent_name, is_virtual,
					 cls_space, inst_space, entries, this);
    // load method
    LoadMethods(cls);
    // add class
    AddClass(cls);
  }
}

/****************************
 * Reads methods
 ****************************/
void Library::LoadMethods(LibraryClass* cls) {
  int number = ReadInt();
  for(int i = 0; i < number; i++) {
    int id = ReadInt();
    frontend::MethodType type = (frontend::MethodType)ReadInt();
    bool is_virtual = (bool)ReadInt();
    bool is_native = (bool)ReadInt();
    bool is_static = (bool)ReadInt();
    const string &name = ReadString();
    const string &rtrn_name = ReadString();
    int params = ReadInt();
    int mem_size = ReadInt();

    // read type parameters 
    backend::IntermediateDeclarations* entries = new backend::IntermediateDeclarations;
    int num_params = ReadInt();
    for(int i = 0; i < num_params; i++) {
      instructions::ParamType type = (instructions::ParamType)ReadInt();
      switch(type) {
      case instructions::OBJ_PARM:
      case instructions::OBJ_ARY_PARM:
        entries->AddParameter(new backend::IntermediateDeclaration(type, ReadInt()));
        break;

      default:
        entries->AddParameter(new backend::IntermediateDeclaration(type));
        break;
      }
    }
    
#ifdef _DEBUG
    const string &msg = "(method: name=" + name + "; id=" + Linker::ToString(id) + "; num_params: " +
      Linker::ToString(params) + "; mem_size=" + Linker::ToString(mem_size) + "; is_native=" + 
      Linker::ToString(is_native) + ")";
    Linker::Show(msg, 0, 1);
#endif
    
    LibraryMethod* mthd = new LibraryMethod(id, name, rtrn_name, type, is_virtual, is_native, 
					    is_static, params, mem_size, cls, entries);
    // load statements
    LoadStatements(mthd);
    
    // add method
    cls->AddMethod(name, mthd);
  }
}

/****************************
 * Reads statements
 ****************************/
void Library::LoadStatements(LibraryMethod* method) {
  vector<LibraryInstr*> instrs;
  int type = ReadInt();
  while(type != END_STMTS) {
    switch(type) {
    case LOAD_INT_LIT:
      instrs.push_back(new LibraryInstr(LOAD_INT_LIT, (INT_VALUE)ReadInt()));
      break;

    case SHL_INT:
      instrs.push_back(new LibraryInstr(SHL_INT, (INT_VALUE)ReadInt()));
      break;

    case SHR_INT:
      instrs.push_back(new LibraryInstr(SHR_INT, (INT_VALUE)ReadInt()));
      break;
      
    case LOAD_INT_VAR: {
      INT_VALUE id = ReadInt();
      MemoryContext mem_context = (MemoryContext)ReadInt();
      instrs.push_back(new LibraryInstr(LOAD_INT_VAR, id, mem_context));
    }
      break;
      
    case LOAD_FLOAT_VAR: {
      INT_VALUE id = ReadInt();
      MemoryContext mem_context = (MemoryContext)ReadInt();
      instrs.push_back(new LibraryInstr(LOAD_FLOAT_VAR, id, mem_context));
    }
      break;

    case STOR_INT_VAR: {
      INT_VALUE id = ReadInt();
      MemoryContext mem_context = (MemoryContext)ReadInt();
      instrs.push_back(new LibraryInstr(STOR_INT_VAR, id, mem_context));
    }
      break;

    case STOR_FLOAT_VAR: {
      INT_VALUE id = ReadInt();
      MemoryContext mem_context = (MemoryContext)ReadInt();
      instrs.push_back(new LibraryInstr(STOR_FLOAT_VAR, id, mem_context));
    }
      break;

    case COPY_INT_VAR: {
      INT_VALUE id = ReadInt();
      MemoryContext mem_context = (MemoryContext)ReadInt();
      instrs.push_back(new LibraryInstr(COPY_INT_VAR, id, mem_context));
    }
      break;

    case COPY_FLOAT_VAR: {
      INT_VALUE id = ReadInt();
      MemoryContext mem_context = (MemoryContext)ReadInt();
      instrs.push_back(new LibraryInstr(COPY_FLOAT_VAR, id, mem_context));
    }
      break;

    case NEW_INT_ARY: {
      INT_VALUE dim = ReadInt();
      instrs.push_back(new LibraryInstr(NEW_INT_ARY, dim));
    }
      break;

    case NEW_FLOAT_ARY: {
      INT_VALUE dim = ReadInt();
      instrs.push_back(new LibraryInstr(NEW_FLOAT_ARY, dim));
    }
      break;
      
    case NEW_BYTE_ARY: {
      INT_VALUE dim = ReadInt();
      instrs.push_back(new LibraryInstr(NEW_BYTE_ARY, dim));

    }
      break;

    case NEW_OBJ_INST: {
      INT_VALUE obj_id = ReadInt();
      instrs.push_back(new LibraryInstr(NEW_OBJ_INST, obj_id));
    }
      break;

    case JMP: {
      INT_VALUE label = ReadInt();
      INT_VALUE cond = ReadInt();
      instrs.push_back(new LibraryInstr(JMP, label, cond));
    }
      break;

    case LBL: {
      INT_VALUE id = ReadInt();
      instrs.push_back(new LibraryInstr(LBL, id));
    }
      break;
      
    case MTHD_CALL: {
      int cls_id = ReadInt();
      int mthd_id = ReadInt();
      int is_native = ReadInt();
      instrs.push_back(new LibraryInstr(MTHD_CALL, cls_id, mthd_id, is_native));
    }
      break;

    case EXT_MTHD_CALL: {
      int is_native = ReadInt();
      const string& cls_name = ReadString();
      const string& mthd_name = ReadString();
#ifdef _DEBUG
      const string &msg = "EXT_MTHD_CALL: class=" + cls_name + ", method=" + mthd_name;
      Linker::Show(msg, 0, 2);
#endif
      instrs.push_back(new LibraryInstr(EXT_MTHD_CALL, is_native, cls_name, mthd_name));
    }
      break;

    case OBJ_INST_CAST: {
      INT_VALUE to_id = ReadInt();
      instrs.push_back(new LibraryInstr(OBJ_INST_CAST, to_id));
    }
      break;

    case LOAD_BYTE_ARY_ELM: {
      INT_VALUE dim = ReadInt();
      MemoryContext mem_context = (MemoryContext)ReadInt();
      instrs.push_back(new LibraryInstr(LOAD_BYTE_ARY_ELM, dim, mem_context));
    }
      break;

    case LOAD_INT_ARY_ELM: {
      INT_VALUE dim = ReadInt();
      MemoryContext mem_context = (MemoryContext)ReadInt();
      instrs.push_back(new LibraryInstr(LOAD_INT_ARY_ELM, dim, mem_context));
    }
      break;
      
    case LOAD_FLOAT_ARY_ELM: {
      INT_VALUE dim = ReadInt();
      MemoryContext mem_context = (MemoryContext)ReadInt();
      instrs.push_back(new LibraryInstr(LOAD_FLOAT_ARY_ELM, dim, mem_context));
    }
      break;

    case STOR_BYTE_ARY_ELM: {
      INT_VALUE dim = ReadInt();
      MemoryContext mem_context = (MemoryContext)ReadInt();
      instrs.push_back(new LibraryInstr(STOR_BYTE_ARY_ELM, dim, mem_context));
    }
      break;

    case STOR_INT_ARY_ELM: {
      INT_VALUE dim = ReadInt();
      MemoryContext mem_context = (MemoryContext)ReadInt();
      instrs.push_back(new LibraryInstr(STOR_INT_ARY_ELM, dim, mem_context));
    }
      break;

    case STOR_FLOAT_ARY_ELM: {
      INT_VALUE dim = ReadInt();
      INT_VALUE mem_context = ReadInt();
      instrs.push_back(new LibraryInstr(STOR_FLOAT_ARY_ELM, dim, mem_context));
    }
      break;

    case RTRN:
      instrs.push_back(new LibraryInstr(RTRN));
      break;

    case TRAP:
      instrs.push_back(new LibraryInstr(TRAP, ReadInt()));
      break;      
      
    case TRAP_RTRN: {
      const int id = instrs.back()->GetOperand();
      if(id == instructions::CPY_STR_ARY) {
	LibraryInstr* cpy_instr = instrs[instrs.size() - 2];
	StringInstruction* str_instr = char_strings[cpy_instr->GetOperand()];
	str_instr->instr = cpy_instr;
      }
      instrs.push_back(new LibraryInstr(TRAP_RTRN, ReadInt()));

      break;
    }
      
    case POP_INT:
      instrs.push_back(new LibraryInstr(POP_INT));
      break;

    case POP_FLOAT:
      instrs.push_back(new LibraryInstr(POP_FLOAT));
      break;
      
    case AND_INT:
      instrs.push_back(new LibraryInstr(AND_INT));
      break;
      
    case OR_INT:
      instrs.push_back(new LibraryInstr(OR_INT));
      break;
      
    case ADD_INT:
      instrs.push_back(new LibraryInstr(ADD_INT));
      break;

    case FLOR_FLOAT:
      instrs.push_back(new LibraryInstr(FLOR_FLOAT));
      break;

    case CEIL_FLOAT:
      instrs.push_back(new LibraryInstr(CEIL_FLOAT));
      break;
      
    case F2I:
      instrs.push_back(new LibraryInstr(F2I));
      break;
      
    case I2F:
      instrs.push_back(new LibraryInstr(I2F));
      break;

    case LOAD_CLS_MEM:
      instrs.push_back(new LibraryInstr(LOAD_CLS_MEM));
      break;
      
    case LOAD_INST_MEM:
      instrs.push_back(new LibraryInstr(LOAD_INST_MEM));
      break;
      
    case SUB_INT:
      instrs.push_back(new LibraryInstr(SUB_INT));
      break;
      
    case MUL_INT:
      instrs.push_back(new LibraryInstr(MUL_INT));
      break;
      
    case DIV_INT:
      instrs.push_back(new LibraryInstr(DIV_INT));
      break;
      
    case MOD_INT:
      instrs.push_back(new LibraryInstr(MOD_INT));
      break;
      
    case EQL_INT:
      instrs.push_back(new LibraryInstr(EQL_INT));
      break;
      
    case NEQL_INT:
      instrs.push_back(new LibraryInstr(NEQL_INT));
      break;
      
    case LES_INT:
      instrs.push_back(new LibraryInstr(LES_INT));
      break;
      
    case GTR_INT:
      instrs.push_back(new LibraryInstr(GTR_INT));
      break;

    case LES_EQL_INT:
      instrs.push_back(new LibraryInstr(LES_EQL_INT));
      break;
      
    case GTR_EQL_INT:
      instrs.push_back(new LibraryInstr(GTR_EQL_INT));
      break;
      
    case ADD_FLOAT:
      instrs.push_back(new LibraryInstr(ADD_FLOAT));
      break;
      
    case SUB_FLOAT:
      instrs.push_back(new LibraryInstr(SUB_FLOAT));
      break;
      
    case MUL_FLOAT:
      instrs.push_back(new LibraryInstr(MUL_FLOAT));
      break;
      
    case DIV_FLOAT:
      instrs.push_back(new LibraryInstr(DIV_FLOAT));
      break;
        
    case EQL_FLOAT:
      instrs.push_back(new LibraryInstr(EQL_FLOAT));
      break;
      
    case NEQL_FLOAT:
      instrs.push_back(new LibraryInstr(ADD_FLOAT));
      break;
      
    case LES_FLOAT:
      instrs.push_back(new LibraryInstr(LES_FLOAT));
      break;
      
    case GTR_FLOAT:
      instrs.push_back(new LibraryInstr(GTR_FLOAT));
      break;
      
    case LOAD_FLOAT_LIT:
      instrs.push_back(new LibraryInstr(LOAD_FLOAT_LIT, ReadDouble()));
      break;
      
    default: {
#ifdef _DEBUG
      InstructionType instr = (InstructionType)type;
      cerr << "-error: " << instr << " -" << endl;
#endif
      exit(1);
    }
      break;
    }
    // update
    type = ReadInt(); 
  }
  method->AddInstructions(instrs);
}
