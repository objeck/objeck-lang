/***************************************************************************
 * VM stack machine.
 *
 *
 * Copyright (c) 2008, 2009 Randy Hollines
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 *
 * - Redistributions of source code must retain the above copyright 
 * notice, this list of conditions and the following disclaimer.
 * - Redistributions in binary form must reproduce the above copyright 
 * notice, this list of conditions and the following disclaimer in 
 * the documentation and/or other materials provided with the distribution.
 * - Neither the name of the StackVM Team nor the names of its 
 * contributors may be used to endorse or promote products derived 
 * from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED 
 * TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 *  PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAinst_mem USED AND ON ANY THEORY OF 
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ***************************************************************************/

#include "stack_intpr.h"

#ifdef _X64
#include "instr_conv_amd64.h"
#else
#include "instr_conv_ia32.h"
#endif

using namespace Runtime;

StackProgram* StackInterpreter::prgm;

void StackInterpreter::Initialize(StackProgram* p) {
  prgm = p;
#ifdef _X64
  JitCompilerAmd64::Initialize(prgm);
#else  
  JitCompilerIA32::Initialize(prgm);  
#endif
  MemoryManager::Initialize(prgm);
}

/********************************
 * Main VM execution method
 ********************************/
void StackInterpreter::Execute(long* stck, long* pos, long p,
			       long cls_id, long mthd_id, bool jit_called) {
  // inital setup
  op_stack = stck;
  stack_pos = pos;
  ip = p;
  // runtime setup
  call_stack_pos = 0;
  mthd = prgm->GetClass(cls_id)->GetMethod(mthd_id);
#ifdef _DEBUG
  cout << "\n---------- Executing Interpretered Code: method_id=" << mthd->GetId() << "; method_name='" << mthd->GetName() << "' ---------\n" << endl;
#endif
  mthd->SetJitCalled(jit_called);
  mem = mthd->ClearMemory();
  if(!jit_called) {
    MemoryManager::Instance()->AddPdaMethodRoot(mthd);
  }
  // execute
  halt = false;
  while(!halt) {
    StackInstr* instr = mthd->GetInstruction(ip++);
    switch(instr->GetType()) {
    case STOR_INT_VAR:
      ProcessStoreInt(instr);
      break;
      
    case STOR_FLOAT_VAR:
      ProcessStoreFloat(instr);
      break;

    case COPY_INT_VAR:
      ProcessCopyInt(instr);
      break;
      
    case COPY_FLOAT_VAR:
      ProcessCopyFloat(instr);
      break;
      
    case LOAD_INT_LIT:
#ifdef _DEBUG
      cout << "stack oper: LOAD_INT_LIT" << endl;
#endif
      PushInt(instr->GetOperand());
      break;

    case SHL_INT: {
#ifdef _DEBUG
      cout << "stack oper: SHL_INT" << endl;
#endif
      long value = PopInt();
      PushInt(value << instr->GetOperand());
    }
      break;

    case SHR_INT: {
#ifdef _DEBUG
      cout << "stack oper: SHR_INT" << endl;
#endif
      long value = PopInt();
      PushInt(value >> instr->GetOperand());
    }
      break;

    case LOAD_FLOAT_LIT:
#ifdef _DEBUG
      cout << "stack oper: LOAD_FLOAT_LIT" << endl;
#endif
      PushFloat(instr->GetFloatOperand());
      break;
      
    case LOAD_INT_VAR:
      ProcessLoadInt(instr);
      break;

    case LOAD_FLOAT_VAR:
      ProcessLoadFloat(instr);
      break;
      
    case ASYNC_JOIN:
#ifdef _DEBUG
      cout << "stack oper: ASYNC_JOIN" << endl;
#endif
#ifndef _WIN32
      pthread_join((pthread_t)PopInt(), NULL);
#endif
      break;
      
    case AND_INT: {
#ifdef _DEBUG
      cout << "stack oper: AND" << endl;
#endif
      long right = PopInt();
      long left = PopInt();
      PushInt(left && right);
    }
      break;

    case OR_INT: {
#ifdef _DEBUG
      cout << "stack oper: OR" << endl;
#endif
      long right = PopInt();
      long left = PopInt();
      PushInt(left || right);
    }
      break;
      
    case ADD_INT:
#ifdef _DEBUG
      cout << "stack oper: ADD" << endl;
#endif
      PushInt(PopInt() + PopInt());
      break;

    case ADD_FLOAT:
#ifdef _DEBUG
      cout << "stack oper: ADD" << endl;
#endif
      PushFloat(PopFloat() + PopFloat());
      break;
      
    case SUB_INT:
#ifdef _DEBUG
      cout << "stack oper: SUB" << endl;
#endif
      PushInt(PopInt() - PopInt());
      break;

    case SUB_FLOAT:
#ifdef _DEBUG
      cout << "stack oper: SUB" << endl;
#endif
      PushFloat(PopFloat() - PopFloat());
      break;
      
    case MUL_INT:
#ifdef _DEBUG
      cout << "stack oper: MUL" << endl;
#endif
      PushInt(PopInt() * PopInt());
      break;
      
    case DIV_INT:
#ifdef _DEBUG
      cout << "stack oper: DIV" << endl;
#endif
      PushInt(PopInt() / PopInt());
      break;

    case MUL_FLOAT:
#ifdef _DEBUG
      cout << "stack oper: MUL" << endl;
#endif
      PushFloat(PopFloat() * PopFloat());
      break;
      
    case DIV_FLOAT:
#ifdef _DEBUG
      cout << "stack oper: DIV" << endl;
#endif
      PushFloat(PopFloat() / PopFloat());
      break;

    case MOD_INT:
#ifdef _DEBUG
      cout << "stack oper: MOD" << endl;
#endif
      PushInt(PopInt() % PopInt());
      break;

    case LES_EQL_INT:
#ifdef _DEBUG
      cout << "stack oper: LES_EQL" << endl;
#endif
      PushInt(PopInt() <= PopInt());
      break;

    case GTR_EQL_INT:
#ifdef _DEBUG
      cout << "stack oper: GTR_EQL" << endl;
#endif
      PushInt(PopInt() >= PopInt());
      break;

    case LES_EQL_FLOAT:
#ifdef _DEBUG
      cout << "stack oper: LES_EQL" << endl;
#endif
      PushInt(PopFloat() <= PopFloat());
      break;

    case GTR_EQL_FLOAT:
#ifdef _DEBUG
      cout << "stack oper: GTR_EQL" << endl;
#endif
      PushInt(PopFloat() >= PopFloat());
      break;

    case EQL_INT:
#ifdef _DEBUG
      cout << "stack oper: EQL" << endl;
#endif
      PushInt(PopInt() == PopInt());
      break;

    case NEQL_INT:
#ifdef _DEBUG
      cout << "stack oper: NEQL" << endl;
#endif
      PushInt(PopInt() != PopInt());
      break;

    case LES_INT:
#ifdef _DEBUG
      cout << "stack oper: LES" << endl;
#endif
      PushInt(PopInt() < PopInt());
      break;
      
    case GTR_INT:
#ifdef _DEBUG
      cout << "stack oper: GTR" << endl;
#endif
      PushInt(PopInt() > PopInt());
      break;
      
    case EQL_FLOAT:
#ifdef _DEBUG
      cout << "stack oper: EQL" << endl;
#endif
      PushInt(PopFloat() == PopFloat());
      break;

    case NEQL_FLOAT:
#ifdef _DEBUG
      cout << "stack oper: NEQL" << endl;
#endif
      PushInt(PopFloat() != PopFloat());
      break;

    case LES_FLOAT:
#ifdef _DEBUG
      cout << "stack oper: LES" << endl;
#endif
      PushInt(PopFloat() < PopFloat());
      break;
      
    case GTR_FLOAT:
#ifdef _DEBUG
      cout << "stack oper: GTR" << endl;
#endif
      PushInt(PopFloat() > PopFloat());
      break;

    case I2F:
#ifdef _DEBUG
      cout << "stack oper: I2F" << endl;
#endif
      PushFloat(PopInt());
      break;
      
    case F2I:
#ifdef _DEBUG
      cout << "stack oper: F2I" << endl;
#endif
      PushInt((long)PopFloat());
      break;
      
    case POP_INT:
#ifdef _DEBUG
      cout << "stack oper: POP_INT" << endl;
#endif
      PopInt();
      break;

    case POP_FLOAT:
#ifdef _DEBUG
      cout << "stack oper: POP_FLOAT" << endl;
#endif
      PopFloat();
      break;
      
    case OBJ_INST_CAST:
      if(!MemoryManager::Instance()->ValidObjectCast((long*)TopInt(), 
						     instr->GetOperand(), 
						     prgm->GetHierarchy())) {
	cerr << "Invalid object cast!" << endl;
	StackErrorUnwind();
	exit(1);
      }
      break;
      
    case RTRN:
      ProcessReturn();
      // return directly back to JIT code
      if(mthd->IsJitCalled()) {
	mthd->SetJitCalled(false);
	return;
      }
      break;
      
    case MTHD_CALL:
      ProcessMethodCall(instr);
      // return directly back to JIT code
      if(mthd->IsJitCalled()) {
	mthd->SetJitCalled(false);
	return;
      }
      break;

    case ASYNC_MTHD_CALL:
      // ProcessAsyncMethodCall(instr);
      cerr << ">>> unsupported instruction (ASYNC_MTHD_CALL); will be available in next release! <<<";
      StackErrorUnwind();
      exit(1);
      break;

    case NEW_BYTE_ARY:
      ProcessNewByteArray(instr);
      break;
      
    case NEW_INT_ARY:
      ProcessNewArray(instr);
      break;

    case NEW_FLOAT_ARY:
      ProcessNewArray(instr, true);
      break;

    case NEW_OBJ_INST:
      ProcessNewObjectInstance(instr);
      break;

    case STOR_BYTE_ARY_ELM:
      ProcessStoreByteArrayElement(instr);
      break;

    case LOAD_BYTE_ARY_ELM:
      ProcessLoadByteArrayElement(instr);
      break;
      
    case STOR_INT_ARY_ELM:
      ProcessStoreIntArrayElement(instr);
      break;

    case LOAD_INT_ARY_ELM:
      ProcessLoadIntArrayElement(instr);
      break;

    case STOR_FLOAT_ARY_ELM:
      ProcessStoreFloatArrayElement(instr);
      break;
      
    case LOAD_FLOAT_ARY_ELM:
      ProcessLoadFloatArrayElement(instr);
      break;
      
    case LOAD_CLS_MEM:
#ifdef _DEBUG
      cout << "stack oper: LOAD_CLS_MEM" << endl;
#endif
      PushInt((long)mthd->GetClass()->GetClassMemory());
      break;

    case LOAD_INST_MEM:
#ifdef _DEBUG
      cout << "stack oper: LOAD_INST_MEM" << endl;
#endif
      PushInt(mem[0]);
      break;

    case TRAP:
    case TRAP_RTRN:
#ifdef _DEBUG
      cout << "stack oper: TRAP" << endl;
#endif
      switch(PopInt()) {      
      case STD_OUT_BOOL:
	cout << ((PopInt() == 0) ? "false" : "true") << endl;
	break;
	
      case STD_OUT_BYTE:
	cout << (void*)PopInt() << endl;
	break;
	
      case STD_OUT_CHAR:
	cout << (char)PopInt() << endl;
	break;
	
      case STD_OUT_INT:
	cout << PopInt() << endl;
	break;
	
      case STD_OUT_FLOAT:
	cout << PopFloat() << endl;
	break;
	
      case STD_OUT_CHAR_ARY: {
	long* array = (long*)PopInt();
        const long size = array[0];
	BYTE_VALUE* str = (BYTE_VALUE*)(array + 3);
	for(long i = 0; i < size; i++) {
	  cout << str[i];
	}
	cout << endl;
      }
	break;

      case STD_OUT_CHAR_ARY_LEN: {
	long* array = (long*)PopInt();
        const long size = PopInt();
	BYTE_VALUE* str = (BYTE_VALUE*)(array + 3);
	for(long i = 0; i < size; i++) {
	  cout << str[i];
	}
	cout << endl;
      }
	break;
	
      case LOAD_CLS_INST_ID:
        PushInt(MemoryManager::Instance()->GetObjectID((long*)PopInt()));
	break;
		
      case LOAD_ARY_SIZE: {
	long* array = (long*)PopInt();
	PushInt(array[0]);
      }
	break;
	
      case CPY_STR_ARY: {
	long index = PopInt();
        BYTE_VALUE* value_str = prgm->GetCharStrings()[index];
        // copy array
	long* array = (long*)PopInt();
        const long size = array[0];
	BYTE_VALUE* str = (BYTE_VALUE*)(array + 3);
	for(long i = 0; i < size; i++) {
          str[i] = value_str[i];
        }
        PushInt((long)array);
      }
        break;

      case STD_IN_CHAR_ARY: {
	char value_str[80];
	cin.getline(value_str, 80);	
        // copy array
	long* array = (long*)PopInt();	
        const long size = strlen(value_str);
	array[0] = size;
	BYTE_VALUE* str = (BYTE_VALUE*)(array + 3);
	for(long i = 0; i < size; i++) {
          str[i] = value_str[i];
        }
        PushInt((long)array);
      }
        break;
      }
      break;
      
    case JMP:
      if(instr->GetOperand2() < 0) {
	ip = mthd->GetLabelIndex(instr->GetOperand()) + 1;
      }
      else if(PopInt() == instr->GetOperand2()) {
	ip = mthd->GetLabelIndex(instr->GetOperand()) + 1;
      } 
      break;
    }
  }
}

/********************************
 * Processes a load integer 
 * variable instruction.
 ********************************/
void StackInterpreter::ProcessLoadInt(StackInstr* instr) {
#ifdef _DEBUG
  cout << "stack oper: LOAD_INT_VAR; index=" << instr->GetOperand() 
       << "; local=" << ((instr->GetOperand2() == LOCL) ? "true" : "false") << endl;
#endif
  if(instr->GetOperand2() == LOCL) {
    PushInt(mem[instr->GetOperand() + 1]);
  }
  else {
    long* cls_inst_mem = (long*)PopInt();
    if(!cls_inst_mem) {
      cerr << "Atempting to de-reference a 'Nil' object or array" << endl;
      StackErrorUnwind();
      exit(1);
    }
    PushInt(cls_inst_mem[instr->GetOperand()]);
  }
}

/********************************
 * Processes a load float 
 * variable instruction.
 ********************************/
void StackInterpreter::ProcessLoadFloat(StackInstr* instr) {
#ifdef _DEBUG
  cout << "stack oper: LOAD_FLOAT_VAR; index=" << instr->GetOperand()
       << "; local=" << ((instr->GetOperand2() == LOCL) ? "true" : "false") << endl;
#endif
  FLOAT_VALUE value;
  if(instr->GetOperand2() == LOCL) {
    memcpy(&value, &mem[instr->GetOperand() + 1], sizeof(FLOAT_VALUE));
  }
  else {
    long* cls_inst_mem = (long*)PopInt();
    if(!cls_inst_mem) {
      cerr << "Atempting to de-reference a 'Nil' object or array" << endl;
      StackErrorUnwind();
      exit(1);
    }
    memcpy(&value, &cls_inst_mem[instr->GetOperand()], sizeof(FLOAT_VALUE));
  }
  PushFloat(value);
}

/********************************
 * Processes a store integer 
 * variable instruction.
 ********************************/
void StackInterpreter::ProcessStoreInt(StackInstr* instr) {
#ifdef _DEBUG
  cout << "stack oper: STOR_INT_VAR; index=" << instr->GetOperand() 
       << "; local=" << ((instr->GetOperand2() == LOCL) ? "true" : "false") << endl;
#endif
  if(instr->GetOperand2() == LOCL) {
    mem[instr->GetOperand() + 1] = PopInt();
  }
  else {
    long* cls_inst_mem = (long*)PopInt();
    if(!cls_inst_mem) {
      cerr << "Atempting to de-reference a 'Nil' object or array" << endl;
      StackErrorUnwind();
      exit(1);
    }
    cls_inst_mem[instr->GetOperand()] = PopInt();
  }
}

/********************************
 * Processes a store float 
 * variable instruction.
 ********************************/
void StackInterpreter::ProcessStoreFloat(StackInstr* instr) {
#ifdef _DEBUG
  cout << "stack oper: STOR_FLOAT_VAR; index=" << instr->GetOperand() 
       << "; local=" << ((instr->GetOperand2() == LOCL) ? "true" : "false") << endl;
#endif
  if(instr->GetOperand2() == LOCL) {   
    FLOAT_VALUE value = PopFloat();   
    memcpy(&mem[instr->GetOperand() + 1], &value, sizeof(FLOAT_VALUE));
  }
  else {
    long* cls_inst_mem = (long*)PopInt();
    if(!cls_inst_mem) {
      cerr << "Atempting to de-reference a 'Nil' object or array" << endl;
      StackErrorUnwind();
      exit(1);
    }
    FLOAT_VALUE value = PopFloat();   
    memcpy(&cls_inst_mem[instr->GetOperand()], &value, sizeof(FLOAT_VALUE));
  }
}

/********************************
 * Processes a copy integer 
 * variable instruction.
 ********************************/
void StackInterpreter::ProcessCopyInt(StackInstr* instr) {
#ifdef _DEBUG
  cout << "stack oper: COPY_INT_VAR; index=" << instr->GetOperand() 
       << "; local=" << ((instr->GetOperand2() == LOCL) ? "true" : "false") << endl;
#endif
  if(instr->GetOperand2() == LOCL) {
    mem[instr->GetOperand() + 1] = TopInt();
  }
  else {
    long* cls_inst_mem = (long*)PopInt();
    if(!cls_inst_mem) {
      cerr << "Atempting to de-reference a 'Nil' object or array" << endl;
      StackErrorUnwind();
      exit(1);
    }
    cls_inst_mem[instr->GetOperand()] = TopInt();
  }
}

/********************************
 * Processes a copy float 
 * variable instruction.
 ********************************/
void StackInterpreter::ProcessCopyFloat(StackInstr* instr) {
#ifdef _DEBUG
  cout << "stack oper: COPY_FLOAT_VAR; index=" << instr->GetOperand() 
       << "; local=" << ((instr->GetOperand2() == LOCL) ? "true" : "false") << endl;
#endif
  if(instr->GetOperand2() == LOCL) {   
    FLOAT_VALUE value = TopFloat();   
    memcpy(&mem[instr->GetOperand() + 1], &value, sizeof(FLOAT_VALUE));
  }
  else {
    long* cls_inst_mem = (long*)PopInt();
    if(!cls_inst_mem) {
      cerr << "Atempting to de-reference a 'Nil' object or array" << endl;
      StackErrorUnwind();
      exit(1);
    }
    FLOAT_VALUE value = TopFloat();   
    memcpy(&cls_inst_mem[instr->GetOperand()], &value, sizeof(FLOAT_VALUE));
  }
}

/********************************
 * Processes a new object instance
 * request.
 ********************************/
void StackInterpreter::ProcessNewObjectInstance(StackInstr* instr) {
#ifdef _DEBUG
  cout << "stack oper: NEW_OBJ_INST: id=" << instr->GetOperand() << endl;
#endif

  long inst_mem = (long)MemoryManager::Instance()->AllocateObject(instr->GetOperand(), op_stack, *stack_pos);
  PushInt(inst_mem);
}

/********************************
 * Processes a new array instance
 * request.
 ********************************/
void StackInterpreter::ProcessNewArray(StackInstr* instr, bool is_float) {
#ifdef _DEBUG
  cout << "stack oper: NEW_INT_ARY/NEW_FLOAT_ARY" << endl;
#endif
  long indices[8];
  long value = PopInt();
  long size = value;
  indices[0] = value;
  long dim = 1;
  for(long i = 1; i < instr->GetOperand(); i++) {
    long value = PopInt();
    size *= value;
    indices[dim++] = value;	
  }
  // double for double
  if(is_float) {
    size *= 2;
  }
  // assumes that doubles are twice the size of integers
  long* mem = (long*)MemoryManager::Instance()->AllocateArray(size + dim + 2, INT_TYPE, op_stack, *stack_pos);
  if(is_float) {
    mem[0] = size / 2;
  }
  else {
    mem[0] = size;
  }
  mem[1] = dim;

  memcpy(mem + 2, indices, dim * sizeof(long));
  PushInt((long)mem);
}

/********************************
 * Processes a new byte array instance
 * request.
 ********************************/
void StackInterpreter::ProcessNewByteArray(StackInstr* instr) {
#ifdef _DEBUG
  cout << "stack oper: NEW_BYTE_ARY" << endl;
#endif
  long indices[8];
  long value = PopInt();
  long size = value;
  indices[0] = value;
  long dim = 1;
  for(long i = 1; i < instr->GetOperand(); i++) {
    long value = PopInt();
    size *= value;
    indices[dim++] = value;
  }
  long* mem = (long*)MemoryManager::Instance()->AllocateArray(size + ((dim + 2) * sizeof(long)), 
			      BYTE_ARY_TYPE, op_stack, *stack_pos);
  mem[0] = size;
  mem[1] = dim;
  memcpy(mem + 2, indices, dim * sizeof(long));
  PushInt((long)mem);
}

/********************************
 * Processes a return instruction.
 * This instruction modifies the 
 * call stack.
 ********************************/
void StackInterpreter::ProcessReturn() {
#ifdef _DEBUG
  cout << "stack oper: RTRN " << endl;
#endif
  MemoryManager::Instance()->RemovePdaMethodRoot(mthd);
  if(!StackEmpty()) {
    mthd = StackPop();
    mem = mthd->GetMemory();
    ip = mthd->GetIp();
  }
  else {
    halt = true;
  }
}

/********************************
 * Processes an synchronous JIT 
 * method call to native code, 
 * this is the pthread target.
 ********************************/
void* StackInterpreter::AsyncCall(void* arg) {
  AsyncHolder* holder = (AsyncHolder*)arg;
  
  long* op_stack = new long[STACK_SIZE];
  long* op_stack_pos = new long;
  (*op_stack_pos) = 0;

  Runtime::StackInterpreter intpr(prgm);
  intpr.Execute(op_stack, 0, 0, holder->cls_id, holder->mthd_id);
  
  delete op_stack;
  op_stack = NULL;

  delete op_stack_pos;
  op_stack_pos = NULL;

  delete holder;
  holder = NULL;

  return NULL;
}

/********************************
 * Processes an asynchronous JIT 
 * method call to native code, 
 * this is the pthread target.
 ********************************/
void* StackInterpreter::AsyncJitCall(void* arg) {
  AsyncHolder* holder = (AsyncHolder*)arg;
  
  long* op_stack = new long[STACK_SIZE];
  long* op_stack_pos = new long;
  (*op_stack_pos) = 0;

#ifdef _X64
  Runtime::JitCompilerAmd64 jit;
#else
  Runtime::JitCompilerIA32 jit;
#endif
  jit.Execute((long*)holder->instance, holder->cls_id, holder->mthd_id, op_stack, op_stack_pos);
  
  delete op_stack;
  op_stack = NULL;

  delete op_stack_pos;
  op_stack_pos = NULL;

  delete holder;
  holder = NULL;

  return NULL;
}

/********************************
 * Processes an asynchronous method
 * call. This instruction executes a
 * VM instance in a separate thread.
 ********************************/
void StackInterpreter::ProcessAsyncMethodCall(StackInstr* instr) {
#ifdef _DEBUG
  cout << "=== ASYNC_MTHD_CALL: class=" << instr->GetOperand() 
       << "; method=" << instr->GetOperand2() << "; compiled=" 
       << (instr->GetOperand3() ? "true" : "false") << " ===" << endl;
#endif
  
  // instance
  long instance = PopInt();
  // save method
  mthd->SetIp(ip);
  StackPush(mthd);
  
  // setup thread
  AsyncHolder* holder = new AsyncHolder;
  holder->cls_id = instr->GetOperand();
  holder->mthd_id = instr->GetOperand2();
  holder->instance = (int32_t*)instance;

#ifndef _WIN32
  // execute jit
  pthread_t thread_id;
  if(instr->GetOperand3()) {
    pthread_create(&thread_id, NULL, AsyncJitCall, (void*)holder);
  }
  else {
    pthread_create(&thread_id, NULL, AsyncCall, (void*)holder);
  }
  PushInt((long)thread_id);
#endif

  
  // restore previous state
  mthd = StackPop();
  ip = mthd->GetIp();
}

/********************************
 * Processes a synchronous method
 * call.
 ********************************/
void StackInterpreter::ProcessMethodCall(StackInstr* instr) {
  // instance
  long instance = PopInt();
  // save method
  mthd->SetIp(ip);
  StackPush(mthd);
  
  // execute JIT call
  if(instr->GetOperand3()) {
#ifdef _X64
    Runtime::JitCompilerAmd64 jit;
#else
    Runtime::JitCompilerIA32 jit;
#endif
    // TODO: don't try and re-compile code that doesn't compile
    if(jit.Compile(instr->GetOperand(), instr->GetOperand2())) {
      // execute
      jit.Execute((long*)instance, instr->GetOperand(), instr->GetOperand2(), op_stack, stack_pos);
      // restore previous state
      mthd = StackPop();
      mem = mthd->GetMemory();
      ip = mthd->GetIp();
    }
    else {
      ProcessInterpretedMethodCall(instr, instance);
    }
  }
  // execute interpreter
  else {
    ProcessInterpretedMethodCall(instr, instance);
  }
}

/********************************
 * Processes an interpreted 
 * synchronous method call.
 ********************************/
void StackInterpreter::ProcessInterpretedMethodCall(StackInstr* instr, long instance) {
  mthd = prgm->GetClass(instr->GetOperand())->GetMethod(instr->GetOperand2());
#ifdef _DEBUG
  cout << "=== MTHD_CALL: id=" << instr->GetOperand() <<","  
       << instr->GetOperand2() << "; name='" << mthd->GetName() << "' ===" << endl;
#endif
  mem = mthd->ClearMemory();
  MemoryManager::Instance()->AddPdaMethodRoot(mthd);
  mem[0] = instance;
  ip = 0;
}

/********************************
 * Processes a load integer array 
 * variable instruction.
 ********************************/
void StackInterpreter::ProcessLoadIntArrayElement(StackInstr* instr) {
#ifdef _DEBUG
  cout << "stack oper: LOAD_INT_ARY_ELM" << endl;
#endif
  long* array = (long*)PopInt();
  const long size = array[0];
  array += 2;
  long index = ArrayIndex(instr, array, size);
  PushInt(array[index + instr->GetOperand()]);
}

/********************************
 * Processes a load store array 
 * variable instruction.
 ********************************/
void StackInterpreter::ProcessStoreIntArrayElement(StackInstr* instr) {
#ifdef _DEBUG
  cout << "stack oper: STOR_INT_ARY_ELM" << endl;
#endif
  long* array = (long*)PopInt();
  const long size = array[0];
  array += 2;
  long index = ArrayIndex(instr, array, size);
  array[index + instr->GetOperand()] = PopInt();
}

/********************************
 * Processes a load byte array 
 * variable instruction.
 ********************************/
void StackInterpreter::ProcessLoadByteArrayElement(StackInstr* instr) {
#ifdef _DEBUG
  cout << "stack oper: LOAD_BYTE_ARY_ELM" << endl;
#endif
  long* array = (long*)PopInt();
  const long size = array[0];
  array += 2;
  long index = ArrayIndex(instr, array, size);
  array += instr->GetOperand();
  PushInt(((BYTE_VALUE*)array)[index]);
}

/********************************
 * Processes a store byte array 
 * variable instruction.
 ********************************/
void StackInterpreter::ProcessStoreByteArrayElement(StackInstr* instr) {
#ifdef _DEBUG
  cout << "stack oper: STOR_BYTE_ARY_ELM" << endl;
#endif
  long* array = (long*)PopInt();
  const long size = array[0];
  array += 2;
  long index = ArrayIndex(instr, array, size);
  array += instr->GetOperand();
  ((BYTE_VALUE*)array)[index] = PopInt();
}

/********************************
 * Processes a load float array 
 * variable instruction.
 ********************************/
void StackInterpreter::ProcessLoadFloatArrayElement(StackInstr* instr) {
#ifdef _DEBUG
  cout << "stack oper: LOAD_FLOAT_ARY_ELM" << endl;
#endif
  long* array = (long*)PopInt();
  const long size = array[0];
  array += 2;
  long index = ArrayIndex(instr, array, size);
  FLOAT_VALUE value;
  memcpy(&value, array + index + instr->GetOperand(), sizeof(FLOAT_VALUE));
  PushFloat(value);
}

/********************************
 * Processes a store float array 
 * variable instruction.
 ********************************/
void StackInterpreter::ProcessStoreFloatArrayElement(StackInstr* instr) {
#ifdef _DEBUG
  cout << "stack oper: STOR_FLOAT_ARY_ELM" << endl;
#endif
  long* array = (long*)PopInt();
  const long size = array[0];
  array += 2;
  long index = ArrayIndex(instr, array,size);  
  FLOAT_VALUE value = PopFloat();
  memcpy(array + index + instr->GetOperand(), &value, sizeof(FLOAT_VALUE));
}
