/***************************************************************************
 * Defines the VM execution model.
 *
 * Copyright (c) 2008, 2009 Randy Hollines
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 *
 * - Redistributions of source code must retain the above copyright 
 * notice, this list of conditions and the following disclaimer.
 * - Redistributions in binary form must reproduce the above copyright 
 * notice, this list of conditions and the following disclaimer in 
 * the documentation and/or other materials provided with the distribution.
 * - Neither the name of the StackVM Team nor the names of its 
 * contributors may be used to endorse or promote products derived 
 * from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED 
 * TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 *  PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF 
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ***************************************************************************/

#ifndef __COMMON_H__
#define __COMMON_H__

#include <iostream>
#include <fstream>
#include <stack>
#include <vector>
#include <list>
#include <map>
#include <string>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include "../shared/instrs.h"
#include "../shared/sys.h"
#include "../shared/traps.h"

#ifdef _MEMCHECK
#include <mcheck.h>
#endif

#ifdef _WIN32
#define _CRTDBG_MAP_ALLOC
#include <stdlib.h>
#include <crtdbg.h>
#endif

using namespace std;
using namespace instructions;

/*
// vm data type mapping
#ifdef _X64
#define INT_LIT INT_LIT INT_LIT
#else
#define INT_LIT long
#endif
#define FLOAT_VALUE double
#define BYTE_VALUE unsigned char
*/

class StackClass;

/********************************
 * StackDclr struct
 ********************************/
typedef struct _StackDclr {
  ParamType type;
  long id;
} StackDclr;

/********************************
 * StackInstr class
 ********************************/
class StackInstr {
  InstructionType type;
  long operand;
  long operand2;
  long operand3;
  FLOAT_VALUE float_operand;
  long native_offset;
  
 public:    
  StackInstr(InstructionType t) {
    type = t;
    operand = native_offset = 0;
  }

  StackInstr(InstructionType t, long o) {
    type = t;
    operand = o;
    native_offset = 0;
  }
  
  StackInstr(InstructionType t, FLOAT_VALUE fo) {
    type = t;
    float_operand = fo;
    operand = native_offset = 0;
  }

  StackInstr(InstructionType t, long o, long o2) {
    type = t;
    operand = o;
    operand2 = o2;
    native_offset = 0;
  }

  StackInstr(InstructionType t, long o, long o2, long o3) {
    type = t;
    operand = o;
    operand2 = o2;
    operand3 = o3;
    native_offset = 0;
  }
  
  ~StackInstr() {
  }
  
  InstructionType GetType() {
    return type;
  }

  void SetType(InstructionType t) {
    type = t;
  }

  long GetOperand() {
    return operand;
  }

  long GetOperand2() {
    return operand2;
  }

  long GetOperand3() {
    return operand3;
  }
  
  void SetOperand(long o) {
    operand = o;
  }

  void SetOperand2(long o2) {
    operand2 = o2;
  }

  void SetOperand3(long o3) {
    operand3 = o3;
  }

  FLOAT_VALUE GetFloatOperand() {
    return float_operand;
  }

  long GetOffset() {
    return native_offset;
  }
  
  void SetOffset(long o) {
    native_offset = o;
  }
};

/********************************
 * JIT compile code
 ********************************/
class NativeCode {
  BYTE_VALUE* code;
  long size;
  FLOAT_VALUE* floats;
    
 public:
  NativeCode(BYTE_VALUE* c, long s, FLOAT_VALUE* f) {
    code = c;
    size = s;
    floats = f;
  }

  ~NativeCode() {
    free(code);
    code = NULL;

    delete[] floats;
    floats = NULL;
  }

  BYTE_VALUE* GetCode() { return code; }
  long GetSize() { return size; }
  FLOAT_VALUE* GetFloats() { return floats; }
};

/********************************
 * StackMethod class
 ********************************/
class StackMethod {
  long id;
  string name;
  vector<StackInstr*> instrs;
  map<long, long> jump_table;
  long param_count;
  long ip;
  long* mem;
  long mem_size;
  NativeCode* native_code;
  bool jit_called;
  MemoryType rtrn_type;
  StackDclr** dclrs;
  long num_dclrs;
  StackClass* cls;

  const string ParseName(const string &name) {
    int state;
    unsigned int index = name.find_last_of(':');
    if(index > 0) {
      string params_name = name.substr(index + 1);
      
      // check return type
      index = 0;
      while(index < params_name.size()) {
	ParamType param;
	switch(params_name[index]) {
	case 'l':
	  param = INT_PARM;
	  state = 0;
	  index++;
	  break;
      
	case 'b':
	  param = INT_PARM;
	  state = 1;
	  index++;
	  break;
      
	case 'i':
	  param = INT_PARM;
	  state = 2;
	  index++;
	  break;
      
	case 'f':
	  param = FLOAT_PARM;
	  state = 3;
	  index++;
	  break;
      
	case 'c':
	  param = INT_PARM;
	  state = 4;
	  index++;
	  break;
    	  
	case 'o':
	  param = OBJ_PARM;
	  state = 5;
	  index = 2;
	  // TODO: fix should be a number
	  while(index < params_name.size() && params_name[index] != '*') {
	    index++;
	  }
	  break; 
	}
	
	// check array
	int dimension = 0;
	while(index < params_name.size() && params_name[index] == '*') {
	  dimension++;
	  index++;
	}
	
	if(dimension) {
	  switch(state) {
	  case 1:
	    param = BYTE_ARY_PARM;
	    break;

	  case 0:
	  case 2:
	  case 4:
	    param = INT_ARY_PARM;
	    break;

	  case 3:
	    param = FLOAT_ARY_PARM;
	    break;

	  case 5:
	    param = OBJ_ARY_PARM;
	    break;
	  }
	}
	
#ifdef _DEBUG
	switch(param) {
	case INT_PARM:
	  cout << "  INT_PARM" << endl;
	  break;

	case FLOAT_PARM:
	  cout << "  FLOAT_PARM" << endl;
	  break;
	  
	case BYTE_ARY_PARM:
	  cout << "  BYTE_ARY_PARM" << endl;
	  break;

	case INT_ARY_PARM:
	  cout << "  INT_ARY_PARM" << endl;
	  break;

	case FLOAT_ARY_PARM:
	  cout << "  FLOAT_ARY_PARM" << endl;
	  break;
    
	case OBJ_PARM:
	  cout << "  OBJ_PARM" << endl;
	  break;

	case OBJ_ARY_PARM:
	  cout << "  OBJ_ARY_PARM" << endl;
	  break;
	}
#endif	
	
	// match ','
	index++;
      }
    }
    
    return name;
  }
  
 public:
  StackMethod(long i, string &n, StackDclr** d, long nd, long p, long m, MemoryType r, StackClass* k) {
    id = i;
    name = ParseName(n);;
    ip = param_count = 0;
    native_code = NULL;
    mem = NULL;
    jit_called = false;
    dclrs = d;
    num_dclrs = nd;
    param_count = p;
    mem_size = InitMemory(m);
    rtrn_type = r;
    cls = k;
  }
  
  ~StackMethod() {
    if(mem) {
      delete[] mem; 
      mem = NULL;
    }
    // clean up   
    if(dclrs) {
      for(int i = 0; i < num_dclrs; i++) {
        StackDclr* tmp = dclrs[i];
        delete tmp;
        tmp = NULL;
      }
      delete[] dclrs;
      dclrs = NULL;
    }
    // clean up   
    if(native_code) {
      delete native_code;
      native_code = NULL;
    }
    // clean up
    while(!instrs.empty()) {
      StackInstr* tmp = instrs.front();
      instrs.erase(instrs.begin());
      // delete
      delete tmp;
      tmp = NULL;
    }
  }

  const string GetName() {
    return name;
  }

  StackClass* GetClass() {
    return cls;
  }
  
  StackDclr** GetDeclarations() { 
    return dclrs; 
  }
  
  const int GetNumberDeclarations() { 
    return num_dclrs; 
  }
  
  void SetJitCalled(bool j) {
    jit_called = j;
  }
  
  bool IsJitCalled() {
    return jit_called;
  }

  void SetNativeCode(NativeCode* c) {
    native_code = c;
  }

  NativeCode* GetNativeCode() {
    return native_code;
  }

  MemoryType GetReturn() {
    return rtrn_type;
  }
  
  void AddLabel(long label_id, long index) {
    jump_table[label_id] = index;
  }
  
  long GetLabelIndex(long label_id) {
    map<long, long>::iterator result = jump_table.find(label_id);
    // not found
    if(result == jump_table.end()) {
      return -1;
    }
    
    return result->second;
  }
  
  void AddInstruction(StackInstr* i) {
    instrs.push_back(i);
  }

  long GetId() {
    return id;
  }

  long GetIp() {
    return ip;
  }
  
  void SetIp(long i) {
    ip = i;
  }
  
  long GetParamCount() {
    return param_count;
  }
  
  void SetParamCount(long c) {
    param_count = c;
  }

  long* GetMemory() {
    return mem;
  }

  long* ClearMemory() {
    for(int i = 0; i < mem_size; i++) {
      mem[i] = 0;
    }

    return mem;
  }
  
  long InitMemory(long size) {
    // +1 is for instance variable
    mem = new long[size + 1];
    for(int i = 0; i < size; i++) {
      mem[i] = 0;
    }

    return size;
  }
  
  long GetInstructionCount() {
    return instrs.size();
  }
  
  StackInstr* GetInstruction(long i) {
    return instrs[i];
  }
};

/********************************
 * StackClass class
 ********************************/
class StackClass {
  map<long, StackMethod*> class_map;
  long id;
  long pid;
  long cls_space;
  long inst_space;
  StackDclr** dclrs;
  long num_dclrs;
  long* cls_mem;

 public:
  StackClass(long i, long p, StackDclr** d, long n, long cs, long is) {
    id = i;
    pid = p;
    dclrs = d;
    num_dclrs = n;
    cls_space = InitMemory(cs);
    inst_space  = is;
  }
  
  ~StackClass() {
    // clean up   
    if(dclrs) {
      for(int i = 0; i < num_dclrs; i++) {
        StackDclr* tmp = dclrs[i];
        delete tmp;
        tmp = NULL;
      }
      delete[] dclrs;
      dclrs = NULL;
    }
    // clean up
    map<long, StackMethod*>::iterator iter;
    for(iter = class_map.begin(); iter != class_map.end(); iter++) {
      StackMethod* temp = iter->second;
      delete temp;
      temp = NULL;
    }
    class_map.clear();

    if(cls_mem) {
      delete[] cls_mem;
      cls_mem = NULL;
    }
  }
  
  long GetId() { 
    return id; 
  }

  long InitMemory(long size) {
    cls_mem = (long*)calloc(size, sizeof(long));
    return size;
  }
  
  StackDclr** GetDeclarations() { 
    return dclrs; 
  }
  
  const int GetNumberDeclarations() { 
    return num_dclrs; 
  }

  long GetParentId() { 
    return id; 
  }
  
  long* GetClassMemory() {
    return cls_mem; 
  }
    
  long GetInstanceMemorySize() { 
    return inst_space; 
  }

  void AddMethod(StackMethod* sf) {
    class_map.insert(make_pair(sf->GetId(), sf));
  }

  StackMethod* GetMethod(long id) {
    map<long, StackMethod*>::iterator result = class_map.find(id);
    if(result != class_map.end()) {
      return result->second;
    }
    
    return NULL;
  }
};

/********************************
 * StackProgram class
 ********************************/
class StackProgram {
  map<long, StackClass*> class_map;
  int* cls_hierarchy;
  BYTE_VALUE** char_strings;
  int num_char_strings;
  
 public:
  StackProgram() {
    cls_hierarchy = NULL;
  }

  ~StackProgram() {
    // clean up
    map<long, StackClass*>::iterator iter;
    for(iter = class_map.begin(); iter != class_map.end(); iter++) {
      StackClass* temp = iter->second;
      delete temp;
      temp = NULL;
    }
    class_map.clear();
    
    if(cls_hierarchy) {
      delete cls_hierarchy;
      cls_hierarchy = NULL;
    }   

    if(char_strings) {
      for(int i = 0; i < num_char_strings; i++) {
        BYTE_VALUE* tmp = char_strings[i];
        delete[] tmp;
        tmp = NULL;
      }
      delete[] char_strings;
      char_strings = NULL;
    }
  }

  void SetCharStrings(BYTE_VALUE** s, int n) {
    char_strings = s;
    num_char_strings = n;
  }

  BYTE_VALUE** GetCharStrings() {
    return char_strings;
  }
  
  void AddClass(StackClass* cls) {
    class_map.insert(make_pair(cls->GetId(), cls));
  }

  void SetHierarchy(int* h) {
    cls_hierarchy = h;
  }
  
  int* GetHierarchy() {
    return cls_hierarchy;
  }

  StackClass* GetClass(long id) {
    map<long, StackClass*>::iterator result = class_map.find(id);
    if(result != class_map.end()) {
      return result->second;
    }
    
    return NULL;
  }
};

#endif
