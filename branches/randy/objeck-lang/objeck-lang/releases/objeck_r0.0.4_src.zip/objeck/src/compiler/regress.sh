#!/bin/bash 
i=41
until [  $i -lt 1 ]; do
	echo -------- prgm$i -----------

#	./obc -src src_programs/tests/prgm$i.obs -lib lang.obl,struct.obl -dest a.obe &> /dev/null
	./obc -src src_programs/tests/prgm$i.obs -lib lang.obl,struct.obl -opt s3 -dest a.obe &> /dev/null

	cd ../vm
	if [ $i = 41 ]; then
		./obr ../compiler/a.obe 7
	else
		./obr ../compiler/a.obe
	fi

	cd ../compiler
	let i-=1

done
